#include<iostream>
#include<string>
#include"Date.h"
using namespace std;

int main(){

    Date date{2003,12,12};

    date.display();
}